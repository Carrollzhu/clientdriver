#define NFS_BUNDLE_VERSION          "dev"
#define NFS_BUNDLE_VERSION_ID       dev
#define NFS_BUNDLE_GIT_VERSION      "HEAD"
#define NFS_BUNDLE_BASE_GIT_VERSION "HEAD"
