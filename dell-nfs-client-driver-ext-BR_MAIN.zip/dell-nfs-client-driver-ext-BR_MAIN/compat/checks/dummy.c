#include <linux/module.h>

void test_dummy(void)
{
}

MODULE_LICENSE("GPL");
