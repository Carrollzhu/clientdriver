#include <linux/module.h>
#include <linux/mm_types.h>

void test_dummy(vm_fault_t v)
{
}

MODULE_LICENSE("GPL");
