#include <linux/module.h>
#include <linux/fs.h>

struct cred *test_dummy(struct cred *a)
{
	return generic_copy_file_range(NULL, 0, NULL, 0, 0, 0);
}

MODULE_LICENSE("GPL");
