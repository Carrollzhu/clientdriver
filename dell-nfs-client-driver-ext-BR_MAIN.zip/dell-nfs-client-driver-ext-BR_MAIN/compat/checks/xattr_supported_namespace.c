#include "linux/module.h"
#include "linux/xattr.h"

void test_wrapper(struct inode *dir, const char *prefix)
{
	xattr_supported_namespace(dir, prefix);
}

MODULE_LICENSE("GPL");
