#define CREATE_TRACE_POINTS
#include "trace_events__string_len.h"

MODULE_LICENSE("GPL");
