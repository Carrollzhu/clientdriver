#ifndef __COMPAT_LINUX_COMPILER_H__
#define __COMPAT_LINUX_COMPILER_H__

#include_next <linux/compiler.h>

#ifndef fallthrough
#define fallthrough
#endif

#endif
