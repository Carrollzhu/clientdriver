#ifndef __COMPAT_REQUEST_KEY_AUTH_TYPE_H__
#define __COMPAT_REQUEST_KEY_AUTH_TYPE_H__

#ifdef COMPAT_DETECT_INCLUDE_REQUEST_KEY_AUTH_TYPE

/* Commit 822ad64d7e46a8e2c8b8a796738d7b657cbb146d */
#include_next <keys/request_key_auth-type.h>

#endif

#endif
