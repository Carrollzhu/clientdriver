#!/bin/bash

exec $(dirname ${BASH_SOURCE})/build.sh src "$@"

